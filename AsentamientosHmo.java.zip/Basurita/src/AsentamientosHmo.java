import java.io.*;

public class AsentamientosHmo {
    public static void main(String[] args) throws Exception{

        //en esta parte nos encargaremos de leer el archivo y rellenar el arreglo con los codigos postales

        String string; // portará los códigos postales

        FileReader fr = new FileReader("postales.txt");//archivo a leer

        FileReader frTemporal = new FileReader("postales.txt");//archivo a leer

        //leemos cantidad de lineas en el archivo "fr" y se las asignamos al array
        LineNumberReader lnr = new LineNumberReader(frTemporal);
        lnr.skip(Long.MAX_VALUE);
        int[] arrayPostales = new int[lnr.getLineNumber()]; // hacemos el arreglo y ahora definiremos su tamaño



     try {

         BufferedReader br = new BufferedReader(fr);

         for (int i = 0; i < arrayPostales.length; i++) {
             string = br.readLine().substring(0,5);
             arrayPostales[i] = Integer.parseInt(string);
         }

     }catch (Exception e){}




////////////////////////////////////////////////////////////////////////////////////////////////////


        /* una vez teniendo nuestro arreglo con todos los codigos postales que analizaremos
        (suponiendo que fueron aleatorios y despreciando el hecho de que los acabamos de generar)
        procederemos a determinar cuantos asentamientos comparten un mismo codigo postal*/



        //creamos una variable que contendrá la postal actual para su uso
        int postal;

        //creamos una variable que cuente las repeticiones de esta postal a lo largo del arreglo
        int repeticiones = 0;
        //creamos variable temporal para comparar
        int postalTemporal = 1111111111;

        //necesitamos este for para recorrer el arreglo de postales
        for (int i = 0; i < arrayPostales.length; i++) {

            postal = arrayPostales[i];//esta variable tiene la postal actual (pos i)

            //un if para ver si no estamos repitiendo datos, si no todo bien y seguimos normal
            if(postalTemporal == postal){
                continue;
            }


            for (int j = 0; j < arrayPostales.length; j++) {//////////////

                if(postal == arrayPostales[j]){
                    repeticiones++;
                }

            }/////////////////////////////////////////////////////////////
            System.out.println("Asentamientos con la postal -"+postal+"-  = Un total de "+repeticiones+" asentamientos");

            /* una vez impreso el dato de repeticiones de esa postal, tenemos que ir a la
            siguiente postal y asegurarnos de que no repitamos, para ello verificaremos
            con una variable temporal */

            postalTemporal = postal;

            //reestablecemos las repeticiones a 0 para la proxima cuenta
            repeticiones = 0;
        }




        }
    }

