import java.io.*;

public class carSales {

    public static void main(String[] args) {

    double[] arrayVentas = new double[1000];

    FileReader fr = null;//lector de el archivo otorgado hacia nosotros


        //ARCHIVO EN localizacion del programa\\
    File file = new File("tabla_ventas.csv");//archivo que contendra datos sumados



    FileWriter fw = null;
    BufferedWriter bw = null;//escritor al archivo
    try{
        fw = new FileWriter(file);
        bw = new BufferedWriter(fw);
    }catch (Exception e){}


    try{
         fr = new FileReader("car_sales.txt");

    }catch (IOException e){
        System.out.println("El archivo no existe");
    }

    BufferedReader br = new BufferedReader(fr);

    String string = "";

    double sumador = 0;

   try{
       br.readLine();//para saltarme la primera linea de datos
   }catch (Exception e){}


        for (int i = 0; i < 1000; i++) {

            try{

                string = br.readLine();

                int indice = (string.indexOf('$')+1);

                string = string.substring(indice);

                double valor = Double.parseDouble(string);

                arrayVentas[i] = valor;//llenamos el arreglo en su totalidad
                System.out.println(arrayVentas[i]);

                sumador = sumador + arrayVentas[i];

                //////////////////////////////////////////////Escribiremos los datos en el .csv nuevo nuestro aquí

                bw.write(arrayVentas[i]+","+"\n");

                //////////////////////////////////////////////

            }catch (Exception e){}


        }//final del for

        try{
            bw.flush();
            bw.close();

        }catch (Exception e){}

        System.out.println("Total de suma de ventas: "+sumador);


    }//fin main
}//fin clase
